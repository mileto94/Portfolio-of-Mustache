# [Portfolio](https://github.com/mileto94/Portfolio-of-Mustache) of [Mustache](http://mustache.github.io/)*
This project uses [Start Bootstrap](http://startbootstrap.com/) and [Freelancer theme](http://startbootstrap.com/template-overviews/freelancer/).

## Creator
[Milka Ferezliyska](https://github.com/mileto94)

## Copyright and License
MIT License

* This porject is written in Bulgarian